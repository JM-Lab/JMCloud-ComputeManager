#!/bin/bash
sudo apt-get update &&
sudo apt-get install -y r-base gdebi-core libapparmor1 &&
## for 64bit
wget -P cloudapp/RStudioServer/ http://download2.rstudio.org/rstudio-server-0.97.551-amd64.deb &&
sudo gdebi -n cloudapp/RStudioServer/rstudio-server-0.97.551-amd64.deb
